﻿<?php

session_start();

if( ! (isset($_SESSION['userid']) && isset($_SESSION['usertype']) && $_SESSION['usertype'] == 'hospital')   )
header("location: ../login.php");


if(isset($_POST['id']) && $_POST['id']!=0)
{
	require_once "../include/database.inc";
	$con = mysqli_connect($servername, $username, $password);
	mysqli_select_db($con , $database);

	$query = "select status from users where userid = '$_POST[id]' ;";
	$result = mysqli_query($con, $query);
	$row = mysqli_fetch_array($result);

	$r=1; if($row[0] ==1) $r =0;

	$query = "update users set status = $r where userid = '$_POST[id]' ;";
	$result = mysqli_query($con, $query);

	if(mysqli_affected_rows($result) >= 0)
    {
        echo "<script>alert('Patient Status Changed'); document.location.href='managepatient.php';</script>";
    }
    else
    {
        echo "<script>alert('Error. Please Retry'); document.location.href = 'managepatient.php';</script>";
    }
}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Cancer Care Portal</title>

<link href="../css/style.css" rel="stylesheet" type="text/css" media="screen" />

<script type="text/javascript">

	function doChange(id)
	{
		if(confirm("Change Status ?"))
		{
			document.getElementById('id').value = id;
	        document.getElementById('form1').action = 'managepatient.php';
	        document.getElementById('form1').submit();
		}
	}

</script>

</head>
<body class style="background-color:rgb(21,127,218);">
<form method='post' id="form1" name="form1">

<input type='hidden' name='id' id='id' value='0' />

<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1><a href="#">Cancer Care Portal</a></h1>
		</div>

	</div>
	<div id="splash"><img src="../images/img01.jpg" alt="" title="" style="width:980px; height:340px;" /></div>
	<!-- end #header -->
	<div id="page">
		<div id="page-bgtop">
			<div id="page-bgbtm">
				<div id="content">
					<div class="post">
						<h2 class="title"><a href="#"style="color: rgb(21,127,218);"> Manage Patient
                        
                        </a></h2>
						<div class="entry" style="line-height:25px;">

					


<?php

	echo "<table width=100%>";
	echo "<tr>";
	echo "<td style='background-color:rgb(21,127,218);color:white;padding-left:5px;'>Name</td>";
	
	echo "<td style='background-color:rgb(21,127,218);color:white;padding-left:5px;'>Mobile</td>";
	echo "<td style='background-color:rgb(21,127,218);color:white;padding-left:5px;'>Place</td>";

	echo "<td style='background-color:rgb(21,127,218);color:white;padding-left:5px;'>Status</td>";
	echo "<td style='background-color:rgb(21,127,218);color:white;padding-left:5px;'>Change</td>";
	echo "</tr>";

	require_once "../include/database.inc";
	$con = mysqli_connect($servername, $username, $password);
	mysqli_select_db($con , $database);

	$query = "select userid, name, mobile,place,
	case status when 1 then 'Active' else 'Inactive' end from users join patientdetails on 
	users.userid = patientdetails.patientid ;";
	$result = mysqli_query($con, $query);

	while($row = mysqli_fetch_array($result))
	{
		echo "<tr>";
		echo "<td style='padding-left:5px;border-bottom:solid 1px rgb(21,127,218);'>$row[1]</td>";
		echo "<td style='padding-left:5px;border-bottom:solid 1px rgb(21,127,218);'>$row[2]</td>";
		echo "<td style='padding-left:5px;border-bottom:solid 1px rgb(21,127,218);'>$row[3]</td>";
	echo "<td style='padding-left:5px;border-bottom:solid 1px rgb(21,127,218);'>$row[4]</td>";
		
		echo "<td style='padding-left:5px;border-bottom:solid 1px rgb(21,127,218);'><a href='#' onclick='doChange($row[0]);'>Change</a></td>";
		echo "</tr>";
	}

	echo "</table>";
?>


						</div>

					</div>

					<div style="clear: both;">&nbsp;</div>
				</div>
				<!-- end #content -->
				<div id="sidebar">
					<ul>
						<li>
							<h2 style="color: rgb(21,127,218);"> Hospital Home</h2>
		                <div >
		                </div>
		                <br />
						</li>
						<li>
							<ul>
                                <li><a href="hospitalhome.php">Home</a></li>
								<li><a href="managepatient.php">Manage Patient</a></li>
								 <li><a href="hospitalupdateprofile.php"  style="text-decoration:none;">Update Profile</a></li>
								 <li><a href="hospitalchangepassword.php" style="text-decoration:none;">Change Password</a></li>
								 <li><a href="managemedicinerequest.php">Manage Medicine Request</a></li>
								 <li><a href="patientlist.php" style="text-decoration:none;">Patient List</a></li>
                                <li><a href="../logout.php">Logout</a></li>
							</ul>
						</li>
					</ul>
				</div>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
		</div>
	</div>
	<!-- end #page -->
</div>

<div id="footer">

	<p> Developed by Shad, Mruthul, Rivin and Sachin  </p>

</div>
</form>
</body>
</html>