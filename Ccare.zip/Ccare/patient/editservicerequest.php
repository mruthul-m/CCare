﻿<?php

session_start();

if( ! (isset($_SESSION['userid']) && isset($_SESSION['usertype']) && $_SESSION['usertype'] == 'patient')   )
header("location: ../login.php");


if(isset($_GET['id']) && $_GET['id'] != "")
{
	require_once("../include/database.inc");

    $con = mysqli_connect($servername, $username, $password);
	mysqli_select_db($con , $database);
	
	$query ="select requestid, description, 
	day(fromdate), month(fromdate), year(fromdate), 
	day(todate), month(todate), year(todate) 
	from servicerequest where requestid = '$_GET[id]';";
	$result = mysqli_query($con, $query);
	$row = mysqli_fetch_array($result);
		//echo $query;
}

if(isset($_POST['tds']) && $_POST['tds'] != "")
{
	require_once("../include/database.inc");

    $con = mysqli_connect($servername, $username, $password);
	mysqli_select_db($con , $database);
	
	$fromdate = $_POST['year'] . '-' . $_POST['month'] . '-' . $_POST['day'] . " 00:00:00.000";
	$todate =  $_POST['year1'] . '-' . $_POST['month1'] . '-' . $_POST['day1'] . " 00:00:00.000";
    
	$query ="update servicerequest set fromdate='$fromdate',todate='$todate',
	description='$_POST[tds]' where requestid = '$_POST[id]';";
	mysqli_query($con, $query);
		//echo $query;
	
	$rows = 0;
    $rows += mysqli_affected_rows($con);
	
    if($rows == 1)
    {
        echo "<script>alert('Service Request Updated Successfully'); document.location.href='manageservicerequest.php';</script>";
    }
    else
    {
        echo "<script>alert('Error. Please Retry'); document.location.href = 'manageservicerequest.php';</script>";
    }
	
}


?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Cancer Care Portal</title>


<script type='text/javascript' src='scripts/validation.js'></script>


<link href="../css/style.css" rel="stylesheet" type="text/css" media="screen" />

<script type="text/javascript">

	function doClear() {
	    document.getElementById('tds').value = "";
		document.getElementById('day').value = "Select Day";
		document.getElementById('month').value = "Select Month";
		document.getElementById('year').value = "Select Year";
		document.getElementById('day1').value = "Select Day";
		document.getElementById('month1').value = "Select Month";
		document.getElementById('year1').value = "Select Year";
		document.getElementById('gender').value = "Select Gender";

		//alert(checkAlphaNumSpace('AABB'));


	}
	var emailreg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
	

	function doLogin() {
	    if (document.getElementById('tds').value == "") {
	        alert("Please Enter Description");
	    }
	   
		else if(document.getElementById('day').value == "Select Day")
		{
			alert("Please Select Day");
		}
		else if(document.getElementById('month').value == "Select Month")
		{
			alert("Please Select Month");
		}
		else if(document.getElementById('year').value == "Select Year")
		{
			alert("Please Select Year");
		}
		
		else if(document.getElementById('day1').value == "Select Day")
		{
			alert("Please Select To Day");
		}
		else if(document.getElementById('month1').value == "Select Month")
		{
			alert("Please Select To Month");
		}
		else if(document.getElementById('year1').value == "Select Year")
		{
			alert("Please Select To Year");
		}
	    else {
	        document.getElementById('form1').action = 'editservicerequest.php';
	        document.getElementById('form1').submit();
	    }
	}

</script>

</head>
<body class style="background-color:rgb(21,127,218);">
<form method='post' id="form1" action="" name="form1">
<input type='hidden' id='id' name='id' 
value='<?php if(isset($row)) echo $row[0]; else echo ""; ?>' />
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1><a href="#">Cancer Care Portal</a></h1>
		</div>

	</div>
	<div id="splash"><img src="../images/img01.jpg" alt="" title="" style="width:980px; height:340px;" /></div>
	<!-- end #header -->
	<div id="page">
		<div id="page-bgtop">
			<div id="page-bgbtm">
				<div id="content">
					<div class="post">
						<h2 class="title"><a href="#"class style="color: rgb(21,127,218);"> Edit Service Request
                        
                        </a></h2>
						<div class="entry" style="line-height:25px;">


                            <label>Description</label><br />
		                    <input type='text' id='tds' name='tds' 
							value = '<?php if(isset($row)) echo $row[1]; else echo ""; ?>'
							class='txt' maxlength='200' style="width:400px;" /> <br />
		                   
							
							<label>From Date</label><br />
							<select id='day' name='day'  class='txt' style="width:125px;">
								<option value='Select Day'>Select Day</option>
								<?php
									for($i=1;$i<=31;$i++)
										if(isset($row) && $row[2] == $i)
											echo "<option value='$i' selected >$i</option>";
										else
											echo "<option value='$i' >$i</option>";

								?>
							</select> &nbsp;

							<select id='month' name='month'  class='txt' style="width:125px;">
								<option value='Select Month'>Select Month</option>
								<option value='1' <?php if(isset($row) && $row[3] == '1') echo "selected"; else echo ""; ?>>January</option>
								<option value='2' <?php if(isset($row) && $row[3] == '2') echo "selected"; else echo ""; ?>>February</option>
								<option value='3' <?php if(isset($row) && $row[3] == '3') echo "selected"; else echo ""; ?>>March</option>
								<option value='4' <?php if(isset($row) && $row[3] == '4') echo "selected"; else echo ""; ?>>April</option>
								<option value='5' <?php if(isset($row) && $row[3] == '5') echo "selected"; else echo ""; ?>>May</option>
								<option value='6' <?php if(isset($row) && $row[3] == '6') echo "selected"; else echo ""; ?>>June</option>
								<option value='7' <?php if(isset($row) && $row[3] == '7') echo "selected"; else echo ""; ?>>July</option>
								<option value='8' <?php if(isset($row) && $row[3] == '8') echo "selected"; else echo ""; ?>>August</option>
								<option value='9' <?php if(isset($row) && $row[3] == '9') echo "selected"; else echo ""; ?>>September</option>
								<option value='10' <?php if(isset($row) && $row[3] == '10') echo "selected"; else echo ""; ?>>October</option>
								<option value='11' <?php if(isset($row) && $row[3] == '11') echo "selected"; else echo ""; ?>>November</option>
								<option value='12' <?php if(isset($row) && $row[3] == '12') echo "selected"; else echo ""; ?>>December</option>
							</select> &nbsp;

							<select id='year' name='year'  class='txt' style="width:125px;">
								<option value='Select Year'>Select Year</option>
								<?php
									for($i=2025;$i>=2020;$i--)
										if(isset($row) && $row[4] == $i)
											echo "<option value='$i' selected >$i</option>";
										else
											echo "<option value='$i' >$i</option>";

								?>
							</select> 
							
							
							<br />
							<label>To Date</label><br />
							<select id='day1' name='day1'  class='txt' style="width:125px;">
								<option value='Select Day'>Select Day</option>
								<?php
									for($i=1;$i<=31;$i++)
										if(isset($row) && $row[5] == $i)
											echo "<option value='$i' selected >$i</option>";
										else
											echo "<option value='$i' >$i</option>";

								?>
							</select> &nbsp;

							<select id='month1' name='month1'  class='txt' style="width:125px;">
								<option value='Select Month'>Select Month</option>
								<option value='1' <?php if(isset($row) && $row[6] == '1') echo "selected"; else echo ""; ?>>January</option>
								<option value='2' <?php if(isset($row) && $row[6] == '2') echo "selected"; else echo ""; ?>>February</option>
								<option value='3' <?php if(isset($row) && $row[6] == '3') echo "selected"; else echo ""; ?>>March</option>
								<option value='4' <?php if(isset($row) && $row[6] == '4') echo "selected"; else echo ""; ?>>April</option>
								<option value='5' <?php if(isset($row) && $row[6] == '5') echo "selected"; else echo ""; ?>>May</option>
								<option value='6' <?php if(isset($row) && $row[6] == '6') echo "selected"; else echo ""; ?>>June</option>
								<option value='7' <?php if(isset($row) && $row[6] == '7') echo "selected"; else echo ""; ?>>July</option>
								<option value='8' <?php if(isset($row) && $row[6] == '8') echo "selected"; else echo ""; ?>>August</option>
								<option value='9' <?php if(isset($row) && $row[6] == '9') echo "selected"; else echo ""; ?>>September</option>
								<option value='10' <?php if(isset($row) && $row[6] == '10') echo "selected"; else echo ""; ?>>October</option>
								<option value='11' <?php if(isset($row) && $row[6] == '11') echo "selected"; else echo ""; ?>>November</option>
								<option value='12' <?php if(isset($row) && $row[6] == '12') echo "selected"; else echo ""; ?>>December</option>
							
							</select> &nbsp;

							<select id='year1' name='year1'  class='txt' style="width:125px;">
								<option value='Select Year'>Select Year</option>
								<?php
									for($i=2025;$i>=2020;$i--)
										if(isset($row) && $row[7] == $i)
											echo "<option value='$i' selected >$i</option>";
										else
											echo "<option value='$i' >$i</option>";

								?>
							</select> 
							
							
							<br />

							
							
							
		                    <div style="padding-top:15px;">
		                    <input type="button" value='Update' class='btn' onclick='doLogin();'  style="width:200px;"  />
		                    <input type="button" value='Clear' class='btn' onclick='doClear();'  style="width:200px;"  />
		                    </div>
		                
                            
                            <br /> <br />

 

						</div>

					</div>

					<div style="clear: both;">&nbsp;</div>
				</div>
				<!-- end #content -->
				<div id="sidebar">
					<ul>
						<li>
							<h2  style="color: rgb(21,127,218);"> Welcome</h2>
		                <div >
		                </div>
		                <br />
						</li>
						<li>
							<ul>
                               <li>
							<ul>
                               <li><a href="patienthome.php">Home</a></li>
								<li><a href="patientupdateprofile.php">Update Profile</a></li>
								<li><a href="patientchangepassword.php"  style="text-decoration:none;">Change Password</a></li>
								<li><a href="requestservice.php">Request Service</a></li>
								<li><a href="servicerequeststatus.php">Service Request Status</a></li>
								
								<li><a href="requestmedicine.php">Request Medicine</a></li>
								<li><a href="medicinerequeststatus.php">Medicine Request Status</a></li>
								<li><a href="managemedicinerequest.php">Manage Medicine Request</a></li>
								 <li><a href="requestblood.php">Request Blood</a></li>
								 <li><a href="submitfeedback.php" >Submit Service Feedback</a></li>
								 <li><a href="bloodrequeststatus.php">Blood Request Status</a></li>
                                <li><a href="managebloodrequest.php">Manage Blood Request</a></li>

								<li><a href="../logout.php">Logout</a></li>
							</ul>
						</li>
							</ul>
						</li>
					</ul>
				</div>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
		</div>
	</div>
	<!-- end #page -->
</div>

<div id="footer">

	<p> Developed by Shad,Mruthul,Rivin and Sachin  </p>

</div>
</form>
</body>
</html>