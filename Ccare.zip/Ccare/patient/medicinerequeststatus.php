<?php

session_start();

if( ! (isset($_SESSION['userid']) && isset($_SESSION['usertype']) && $_SESSION['usertype'] == 'patient')   )
header("location: ../login.php");


?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Cancer Care Portal</title>

<link href="../css/style.css" rel="stylesheet" type="text/css" media="screen" />

<script type="text/javascript">

	function doClear() {
	    document.getElementById('tun').value = "";
	    document.getElementById('tpw').value = "";
	}

	function doLogin() {
	    if (document.getElementById('tun').value == "") {
	        alert("Please Enter User Name");
	    }
	    else if (document.getElementById('tpw').value == "") {
	        alert("Please Enter Password");
	    }
	    else {
	        document.getElementById('form1').action = 'login.php';
	        document.getElementById('form1').submit();
	    }
	}

</script>

</head>
<body class style="background-color:rgb(21,127,218);">
<form method='post' id="form1" action="" name="form1">
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1><a href="#">Cancer Care Portal</a></h1>
		</div>

	</div>
	<div id="splash"><img src="../images/img01.jpg" alt="" title="" style="width:980px; height:340px;" /></div>
	<!-- end #header -->
	<div id="page">
		<div id="page-bgtop">
			<div id="page-bgbtm">
				<div id="content">
					<div class="post">
						<h2 class="title"><a href="#"class style="color: rgb(21,127,218);"> Medicine Request Status
                        
                        </a></h2>
						<div class="entry" style="line-height:25px;">

                          
 <?php

	echo "<table width=100%>";
	echo "<tr>";
	echo "<td style='background-color:rgb(21,127,218);color:white;padding-left:5px;'>Medicine</td>";
	echo "<td style='background-color:rgb(21,127,218);color:white;padding-left:5px;'>Quantity</td>";
	echo "<td style='background-color:rgb(21,127,218);color:white;padding-left:5px;'>Date </td>";
	echo "<td style='background-color:rgb(21,127,218);color:white;padding-left:5px;'>Hospital </td>";
	echo "<td style='background-color:rgb(21,127,218);color:white;padding-left:5px;'>Approved Date </td>";
	echo "</tr>";

	require_once "../include/database.inc";
	$con = mysqli_connect($servername, $username, $password);
	mysqli_select_db($con , $database);

	$query = "select genericname, quantity, 
	concat(day(requestdate), '/', month(requestdate), '/', year(requestdate)) , 
	hospitaldetails.name,
	ifnull( 
	concat(day(medicinerequest.approveddate), '/', month(medicinerequest.approveddate), '/', 
	year(medicinerequest.approveddate)), 'Processing')
	from medicinerequest join hospitaldetails on 
	medicinerequest.hospitalid = hospitaldetails.hospitalid 
	where medicinerequest.patientid = '$_SESSION[userid]'
	 ;";
	//echo $query;
	$result = mysqli_query($con, $query);

	while($row = mysqli_fetch_array($result))
	{
		echo "<tr>";
		echo "<td style='padding-left:5px;border-bottom:solid 1px rgb(21,127,218);'>$row[0]</td>";
		echo "<td style='padding-left:5px;border-bottom:solid 1px rgb(21,127,218);'>$row[1]</td>";
		echo "<td style='padding-left:5px;border-bottom:solid 1px rgb(21,127,218);'>$row[2]</td>";
		echo "<td style='padding-left:5px;border-bottom:solid 1px rgb(21,127,218);'>$row[3]</td>";
		echo "<td style='padding-left:5px;border-bottom:solid 1px rgb(21,127,218);'>$row[4]</td>";
		echo "</tr>";
	}

	echo "</table>";
?>


 

						</div>

					</div>

					<div style="clear: both;">&nbsp;</div>
				</div>
				<!-- end #content -->
				<div id="sidebar">
					<ul>
						<li>
							<h2  style="color: rgb(21,127,218);"> Patient Home</h2>
		                <div >
		                </div>
		                <br />
						</li>
						<li>
							<ul>
                                
                                 <li><a href="patienthome.php">Home</a></li>
								<li><a href="patientupdateprofile.php">Update Profile</a></li>
								<li><a href="patientchangepassword.php"  style="text-decoration:none;">Change Password</a></li>
								<li><a href="requestservice.php">Request Service</a></li>
								<li><a href="servicerequeststatus.php">Service Request Status</a></li>
								
								<li><a href="requestmedicine.php">Request Medicine</a></li>
								<li><a href="medicinerequeststatus.php">Medicine Request Status</a></li>
								<li><a href="managemedicinerequest.php">Manage Medicine Request</a></li>
								 <li><a href="requestblood.php">Request Blood</a></li>
								 <li><a href="submitfeedback.php" >Submit Service Feedback</a></li>
								 <li><a href="bloodrequeststatus.php">Blood Request Status</a></li>
                                <li><a href="managebloodrequest.php">Manage Blood Request</a></li>

								<li><a href="../logout.php">Logout</a></li>
							</ul>
						</li>
					</ul>
				</div>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
		</div>
	</div>
	<!-- end #page -->
</div>

<div id="footer">

	<p> Developed by Shad,Mruthul,Rivin and Sachin </p>

</div>
</form>
</body>
</html>