﻿<?php

session_start();
if( ! (isset($_SESSION['userid']) && isset($_SESSION['usertype']) && $_SESSION['usertype'] == 'patient')   )
header("location: ../login.php");

if(isset($_GET['id']) && $_GET['id'] != "0")
{
	require_once("../include/database.inc");

    $con = mysqli_connect($servername, $username, $password);
	mysqli_select_db($con , $database);

    $query ="select requestid, medicinename, genericname, quantity  from
	medicinerequest where requestid = '$_GET[id]'  ;";
	$result = mysqli_query($con, $query);
	$row = mysqli_fetch_array($result);
}


if(isset($_POST['mn']) && $_POST['mn'] != "")
{
	require_once("../include/database.inc");

    $con = mysqli_connect($servername, $username, $password);
	mysqli_select_db($con , $database);

    $query ="update  medicinerequest set genericname='$_POST[gn]',
	quantity='$_POST[qn]', medicinename='$_POST[mn]' 
	where requestid = '$_POST[id]'  ;";
	mysqli_query($con, $query);
		
    $rows = 0;
    $rows += mysqli_affected_rows($con);

    if($rows == 1)
    {
        echo "<script>alert(' Medicine Request Updated'); document.location.href='managemedicinerequest.php';</script>";
    }
    else
    {
        echo "<script>alert('Error. Please Retry'); document.location.href = 'managemedicinerequest.php';</script>";
    }
}


?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Cancer Care Portal</title>


<script type='text/javascript' src='scripts/validation.js'></script>


<link href="../css/style.css" rel="stylesheet" type="text/css" media="screen" />

<script type="text/javascript">

	function doClear() {
	    document.getElementById('mn').value = "";
		document.getElementById('gn').value = "";
		document.getElementById('qn').value = "";
	}

	

	function doRequest() {
	    if (document.getElementById('mn').value == "") {
	        alert("Please Enter Medicine Name");
	    }
	   else if (document.getElementById('gn').value == "") {
	        alert("Please Enter Generic Name");
	    }
	    else if (document.getElementById('qn').value == "") {
	        alert("Please Enter Quantity");
	    }
	   else {
	        document.getElementById('form1').action = 'editmedicinerequest.php';
	        document.getElementById('form1').submit();
	    }
	}

</script>

</head>
<body class style="background-color:rgb(21,127,218);">
<form method='post' id="form1" action="" name="form1">
<input type='hidden' id='id' name='id' 
value = '<?php if(isset($row)) echo $row[0]; else echo ""; ?>' />
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1><a href="#">Cancer Care Portal</a></h1>
		</div>

	</div>
	<div id="splash"><img src="../images/img01.jpg" alt="" title="" style="width:980px; height:340px;" /></div>
	<!-- end #header -->
	<div id="page">
		<div id="page-bgtop">
			<div id="page-bgbtm">
				<div id="content">
					<div class="post">
						<h2 class="title"><a href="#"class style="color: rgb(21,127,218);"> Request Medicine
                        
                        </a></h2>
						<div class="entry" style="line-height:25px;">


                            <label>Medicine Name</label><br />
		                    <input type='text' id='mn' name='mn' 
							value = '<?php if(isset($row)) echo $row[1]; else echo ""; ?>' 
							class='txt' maxlength='30' style="width:400px;" /> <br />
		                   
						    <label>Generic Name</label><br />
		                    <input type='text' id='gn' name='gn' 
							value = '<?php if(isset($row)) echo $row[2]; else echo ""; ?>' 
							class='txt' maxlength='30' style="width:400px;" /> <br />
		                   
						    <label>Quantity</label><br />
		                    <input type='text' id='qn' name='qn' 
							value = '<?php if(isset($row)) echo $row[3]; else echo ""; ?>' 
							class='txt' maxlength='30' style="width:400px;" /> <br />
		                   
					

							
							
							
		                    <div style="padding-top:15px;">
		                    <input type="button" value='Update' class='btn' onclick='doRequest();'  style="width:200px;"  />
		                    <input type="button" value='Clear' class='btn' onclick='doClear();'  style="width:200px;"  />
		                    </div>
		                
                            
                            <br /> <br />

 

						</div>

					</div>

					<div style="clear: both;">&nbsp;</div>
				</div>
				<!-- end #content -->
				<div id="sidebar">
					<ul>
						<li>
							<h2  style="color: rgb(21,127,218);"> Welcome</h2>
		                <div >
		                </div>
		                <br />
						</li>
						<li>
							<ul>
                               <li>
							<ul>
                               <li><a href="patienthome.php">Home</a></li>
								<li><a href="patientupdateprofile.php">Update Profile</a></li>
								<li><a href="patientchangepassword.php"  style="text-decoration:none;">Change Password</a></li>
								<li><a href="requestservice.php">Request Service</a></li>
								<li><a href="servicerequeststatus.php">Service Request Status</a></li>
								
								<li><a href="requestmedicine.php">Request Medicine</a></li>
								<li><a href="medicinerequeststatus.php">Medicine Request Status</a></li>
								<li><a href="managemedicinerequest.php">Manage Medicine Request</a></li>
								 <li><a href="requestblood.php">Request Blood</a></li>
								 <li><a href="submitfeedback.php" >Submit Service Feedback</a></li>
								 <li><a href="bloodrequeststatus.php">Blood Request Status</a></li>
                                <li><a href="managebloodrequest.php">Manage Blood Request</a></li>

								<li><a href="../logout.php">Logout</a></li>
							
							</ul>
						</li>
							</ul>
						</li>
					</ul>
				</div>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
		</div>
	</div>
	<!-- end #page -->
</div>

<div id="footer">

	<p> Developed by Shad,Mruthul,Rivin and Sachin  </p>

</div>
</form>
</body>
</html>