﻿<?php

	session_start();

	unset($_POST['userid']);
	unset($_POST['usertype']);

	echo "<script>document.location.href='login.php';</script>";

?>