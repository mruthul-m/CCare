<?php

if(isset($_POST['tun']) && $_POST['tun'] != "")
{
	require_once("include/database.inc");

    $con = mysqli_connect($servername, $username, $password);
	mysqli_select_db($con , $database);

$query ="insert into users (username, password, usertype, doj, mobile, emailid, status) 
		values ('$_POST[tun]', '$_POST[tpw]', 'patient', now(), '$_POST[tmb]', '$_POST[tem]', 1); ";
	
	mysqli_query($con, $query);
		
    $rows = 0;
    $rows += mysqli_affected_rows($con);

	//2019-28-01
	$dob = $_POST['year'] . '-' . $_POST['month'] . '-' . $_POST['day'] . " 00:00:00.000";

    $query ="insert into patientdetails (patientid, name, dob, gender,place, address ) 
		values ( (select max(userid) from users),  '$_POST[tnm]', '$dob', '$_POST[gender]' , '$_POST[tpl]', '$_POST[tad]' );";
    

	mysqli_query($con, $query);
    $rows += mysqli_affected_rows($con);
	

    if($rows ==2)
    {
        echo "<script>alert('Patient Registration Successfull'); document.location.href='login.php';</script>";
    }
    else
    {
        echo "<script>alert('Error. Please Retry'); document.location.href = 'patientregistration.php';</script>";
    }
	
}


?>



<html>
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Cancer Care Portal</title><link rel="stylesheet" href="css/bootstrap.min.css">
 <link rel="stylesheet" href="css/custom.css">
  <link rel="stylesheet" href="css/colors.css">


<script type='text/javascript' src='scripts/validation.js'></script>


<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />

<script type="text/javascript">

	function doClear() {
	    document.getElementById('tun').value = "";
	    document.getElementById('tpw').value = "";
		document.getElementById('tcp').value = "";
		document.getElementById('tem').value = "";
		document.getElementById('tmb').value = "";
		document.getElementById('tnm').value = "";
		document.getElementById('tpl').value = "";
		document.getElementById('tad').value = "";
		document.getElementById('day').value = "Select Day";
		document.getElementById('month').value = "Select Month";
		document.getElementById('year').value = "Select Year";
		document.getElementById('gender').value = "Select Gender";
		


		


	}
	var emailreg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
	

	function doLogin() {
	    if (document.getElementById('tun').value == "") {
	        alert("Please Enter User Name");
	    }
	    else if (document.getElementById('tpw').value == "") {
	        alert("Please Enter Password");
	    }
		else if (document.getElementById('tpw').value != document.getElementById('tcp').value) {
	        alert("Passwords should Match");
	    }
		else if (document.getElementById('tem').value == "") {
	        alert("Please Enter Email ID");
	    }
		else if ( emailreg.test(document.getElementById('tem').value) == false)
		{
	        alert("Invalid Email ID");
	    }
		else if (document.getElementById('tmb').value == "") {
	        alert("Please Enter Mobile");
	    }
		else if (isNaN(document.getElementById('tmb').value)) {
	        alert("Invalid Mobile Number");
	    }
		else if (document.getElementById('tmb').value.length != 10) {
	        alert("Invalid Mobile");
	    }
		else if(document.getElementById('tnm').value == "")
		{
			alert("Please Enter Patient Name");
		}
		/*else if( checkAlphaNumSpace(document.getElementById('tnm').value) == false)
		{
			alert("Invalid Patient Name");
		}*/
		else if(document.getElementById('day').value == "Select Day")
		{
			alert("Please Select Day");
		}
		else if(document.getElementById('month').value == "Select Month")
		{
			alert("Please Select Month");
		}
		else if(document.getElementById('year').value == "Select Year")
		{
			alert("Please Select Year");
		}
		else if(document.getElementById('gender').value == "Select Gender")
		{
			alert("Please Select Gender");
		}
	    else {
	        document.getElementById('form1').action = 'patientregistration.php';
	        document.getElementById('form1').submit();
	    }
	}

</script>

</head>
<body class style="background-color:rgb(21,127,218);">
<form method='post' id="form1" action="" name="form1">
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1><a href="#">Cancer Care Portal</a></h1>
		</div>

	</div>
	<div id="splash"><img src="images/img01.jpg" alt="" title="" style="width:980px; height:340px;" /></div>
	<!-- end #header -->
	<div id="page">
		<div id="page-bgtop">
			<div id="page-bgbtm">
				<div id="content">
					<div class="post">
						<h2 class="title"><a href="#"class style="color: rgb(21,127,218);"> Patient Registration
                        
                        </a></h2>
						<div class="entry" style="line-height:25px;">


                            <label>User Name</label><br />
		                    <input type='text'autocomplete='off'  id='tun' name='tun' class='txt' maxlength='14' style="width:400px;" /> <br />
		                   
							<label>Password</label><br />
		                    <input type='password' id='tpw' name='tpw'  class='txt'  maxlength='14'  style="width:400px;" /> <br />
							
							<label> Confirm Password</label><br />
		                    <input type='password' id='tcp' name='tcp'  class='txt'  maxlength='14'  style="width:400px;" /> <br />
							
							<label>Email Id</label><br />
		                    <input type='text' id='tem' name='tem' class='txt' maxlength='100' style="width:400px;" /> <br />
							
							<label>Mobile</label><br />
		                    <input type='text' autocomplete='off' id='tmb' name='tmb' class='txt' maxlength='12' style="width:400px;" /> <br />
							
							<label>Patient Name</label><br />
		                    <input type='text' autocomplete='off' id='tnm' name='tnm' class='txt' maxlength='50' style="width:400px;" /> <br />
							
							<label>Place</label><br />
		                    <input type='text' autocomplete='off' id='tpl' name='tpl' class='txt' maxlength='50' style="width:400px;" /> <br />

							<label>Address</label><br />
		                    <input type='text' autocomplete='off' id='tad' name='tad' class='txt' maxlength='250' style="width:400px;" /> <br />
							<label>Birth Date</label><br />
							<select id='day' name='day'  class='txt' style="width:125px;">
								<option value='Select Day'>Select Day</option>
								<?php
									for($i=1;$i<=31;$i++)
										echo "<option value='$i'>$i</option>";

								?>
							</select> &nbsp;

							<select id='month' name='month'  class='txt' style="width:125px;">
								<option value='Select Month'>Select Month</option>
								<option value='1'>January</option>
								<option value='2'>February</option>
								<option value='3'>March</option>
								<option value='4'>April</option>
								<option value='5'>May</option>
								<option value='6'>June</option>
								<option value='7'>July</option>
								<option value='8'>August</option>
								<option value='9'>September</option>
								<option value='10'>October</option>
								<option value='11'>November</option>
								<option value='12'>December</option>
							</select> &nbsp;

							<select id='year' name='year'  class='txt' style="width:125px;">
								<option value='Select Year'>Select Year</option>
								<?php
									for($i=2020;$i>=1900;$i--)
										echo "<option value='$i'>$i</option>";

								?>
							</select> 
							
							
							<br />

							<label>Gender</label><br />
							<select id='gender' name='gender'  class='txt'>
								<option value='Select Gender'>Select Gender</option>
								<option value='Male'>Male</option>
								<option value='Female'>Female</option>
								
							</select> 
							
							<br />
							
							
		                   
							 <div style="padding-top:15px;">
							
                                    <div class="form-group">
                                      
                                     <div class="left"><button type="submit" onclick='doLogin();'>submit</button>&nbsp;&nbsp;&nbsp;
                                    
                        <button type="clear" onclick='doClear();'>Clear</button></div>
		                    
		                    
		                    </div></div>
		                
                            
                            <br /> <br />

 

						</div>

					</div>

					<div style="clear: both;">&nbsp;</div>
				</div>
				<!-- end #content -->
				<div id="sidebar">
					<ul>
						<li>
							<h2  style="color: rgb(21,127,218);"> Welcome</h2>
		                <div >
		                </div>
		                <br />
						</li>
						<li>
							<ul>
                                <li><a href="index.html">Home Page</a></li>
								<li><a href="login.php">Login Page</a></li>
								<li><a href="hospitalregistration.php"  >Hospital Registration</a></li>
                                <li><a href="patientregistration.php"  >Patient Registration</a></li>
								 <li><a href="activistregistration.php" >Activist Registration</a></li>
                                <li><a href="forgotpassword.php">Forgot Password</a></li>
							</ul>
						</li>
					</ul>
				</div>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
		</div>
	</div>
	<!-- end #page -->
</div>

<div id="footer">

	<p> Developed by Shad,Mruthul,Rivin and Sachin  </p>

</div>
</form>
</body>
</html>