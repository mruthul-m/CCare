<?php

if(isset($_POST['tun']) && $_POST['tun'] != "") 
{

	require_once("include/database.inc");

    $con = mysqli_connect($servername, $username, $password);
	mysqli_select_db($con , $database);

    $query ="insert into users (username, password, usertype, doj, mobile, emailid, status) 
		values ('$_POST[tun]', '$_POST[tpw]', 'activist', now(), '$_POST[tmb]', '$_POST[tem]', 0); ";
		
	mysqli_query($con, $query);
		
    $rows = 0;
    $rows += mysqli_affected_rows($con);

    $query ="insert into activistdetails (activistid, name, location, address ,gender) 
		values ( (select max(userid) from users ),  '$_POST[tan]', '$_POST[tlo]','$_POST[tad]', '$_POST[gender]');";
        
	mysqli_query($con, $query);
    $rows += mysqli_affected_rows($con);

    if($rows == 2)
    {
        echo "<script>alert('Activist Registration Successfull. Please Login After Approval'); document.location.href='login.php';</script>";
    }
    else
    {
        echo "<script>alert('Error. Please Retry'); document.location.href = 'activistregistration.php';</script>";
    }
	
}


?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Cancer Care Portal</title>

<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />

<script type="text/javascript">

	function doClear() {
	    document.getElementById('tan').value = "";
	    document.getElementById('tlo').value = "";
	    document.getElementById('tad').value = "";
	    document.getElementById('tun').value = "";
	    document.getElementById('tpw').value = "";
	    document.getElementById('tcp').value = "";
		document.getElementById('tem').value = "";
		document.getElementById('tmb').value = "";

		document.getElementById('gender').value = "Select Gender";
	}
	var emailreg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

	function doLogin() {
	    if (document.getElementById('tan').value == "") {
	        alert("Please Enter Activist Name");
	    }
		else if(document.getElementById('tlo').value == "")
		{
		alert("Please Enter Location");
		}
		else if(document.getElementById('tad').value == "")
		{
		alert("Please Enter Address");
		}
		else if(document.getElementById('gender').value == "Select Gender")
		{
			alert("Please Select Gender");
		}
	    else if (document.getElementById('tun').value == "") {
	        alert("Please Enter User Name");
	    }
		else if(document.getElementById('tpw').value == "")
		{
		alert("Please Enter Password");
		}	
		else if (document.getElementById('tpw').value != document.getElementById('tcp').value)
		 {
	        alert("Password should Match");
	    }
		else if (document.getElementById('tem').value == "")
		 {
	        alert("Please Enter Email ID");
	    }
		else if ( emailreg.test(document.getElementById('tem').value) == false)
		{
	        alert("Invalid Email ID");
	    }
		else if (document.getElementById('tmb').value == "") {
	        alert("Please Enter Mobile");
	    }
		else if (isNaN(document.getElementById('tmb').value)) {
	        alert("Invalid Mobile Number");
	    }
		else if (document.getElementById('tmb').value.length != 10) {
	        alert("Invalid Mobile Number");
	    }
		
	    else {
	        document.getElementById('form1').action = 'activistregistration.php';
	        document.getElementById('form1').submit();
	    }
	}

</script>

</head>
<body  class style="background-color:rgb(21,127,218);">
<form method='post' id="form1" action="" name="form1">
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1><a href="#">Cancer Care Portal</a></h1>
		</div>

	</div>
	<div id="splash"><img src="images/img01.jpg" alt="" title="" style="width:980px; height:340px;" /></div>
	<!-- end #header -->
	<div id="page">
		<div id="page-bgtop">
			<div id="page-bgbtm">
				<div id="content">
					<div class="post">
						<h2 class="title"><a href="#"class style="color: rgb(21,127,218);"> Activist Registration
                        
                        </a></h2>
						<div class="entry" style="line-height:25px;">


                            <label>Activist Name</label><br />
		                    <input type='text' id='tan' name='tan' class='txt' maxlength='14' style="width:400px;" /> <br />
		                    <label>Location</label><br />
		                    <input type='text' id='tlo' name='tlo' class='txt' maxlength='14' style="width:400px;" /> <br />
		                    <label>Address</label><br />
		                    <input type='text' id='tad' name='tad' class='txt' maxlength='125' style="width:400px;" /> <br />
							<label>Gender</label><br />
							<select id='gender' name='gender'  class='txt'style="width:400px;">
								<option value='Select Gender'>Select Gender</option>
								<option value='Male'>Male</option>
								<option value='Female'>Female</option>
								
							</select> 
							
							<br />
		                    <label>User Name</label><br />
		                    <input type='text' id='tun' name='tun' class='txt' maxlength='14' style="width:400px;" /> <br />
		                   
						  
							<label>Password</label><br />
		                    <input type='password' id='tpw' name='tpw'  class='txt'  maxlength='14'  style="width:400px;" /> <br />
							
							<label> Confirm Password</label><br />
		                    <input type='password' id='tcp' name='tcp'  class='txt'  maxlength='14'  style="width:400px;" /> <br />
							
							<label>Email Id</label><br />
		                    <input type='text' id='tem' name='tem' class='txt' maxlength='100' style="width:400px;" /> <br />
							
							<label>Mobile</label><br />
		                    <input type='text' id='tmb' name='tmb' class='txt' maxlength='12' style="width:400px;" /> <br />
							
							
							
							
							
		                    <div style="padding-top:15px;">
		                    <input type="button" value='Submit' class='btn' onclick='doLogin();'  style="width:200px;"  />
		                    <input type="button" value='Clear' class='btn' onclick='doClear();'  style="width:200px;"  />
		                    </div>
		                
                            
                            <br /> <br />

 

						</div>

					</div>

					<div style="clear: both;">&nbsp;</div>
				</div>
				<!-- end #content -->
				<div id="sidebar">
					<ul>
						<li>
							<h2 style="color: rgb(21,127,218);"> Welcome</h2>
							
		                <div >
		                </div>
		                <br />
						</li>
						<li>
							<ul>
                                <li><a href="index.html">Home Page</a></li>
								<li><a href="login.php">Login Page</a></li>
								<li><a href="hospitalregistration.php"  style="text-decoration:none;">Hospital Registration</a></li>
                                <li><a href="patientregistration.php"  style="text-decoration:none;">Patient Registration</a></li>
								 <li><a href="activistregistration.php"  style="text-decoration:none;">Activist Registration</a></li>
                                <li><a href="forgotpassword.php">Forgot Password</a></li>
							</ul>
						</li>
					</ul>
				</div>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
		</div>
	</div>
	<!-- end #page -->
</div>

<div id="footer">

	<p> Developed by Shad,Mruthul,Rivin and Sachin </p>

</div>
</form>
</body>
</html>