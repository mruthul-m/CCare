<?php

if(isset($_POST['tun']) && $_POST['tun'] != "")
{

	require_once("include/database.inc");

    $con = mysqli_connect($server, $username, $password);
	mysqli_select_db($con , $database);

    $query ="insert into users (username, password, usertype, doj, mobile, emailid, status) 
		values ('$_POST[tun]', '$_POST[tpw]', 'hospital', now(), '$_POST[tmb]', '$_POST[tem]', 0); ";
	mysqli_query($con, $query);
		
    $rows = 0;
    $rows += mysqli_affected_rows($con);

    $query ="insert into hospitaldetails (hospitalid, name, place, address, contactperson, website) 
		values ( (select max(userid) from users),  '$_POST[tnm]', '$_POST[tpl]', '$_POST[tad]','$_POST[tct]', '$_POST[tws]'   );";
        
	mysqli_query($con, $query);
    $rows += mysqli_affected_rows($con);

    if($rows == 2)
    {
        echo "<script>alert('Hospital Registration Successfull. Please Login After Approval'); document.location.href='login.php';</script>";
    }
    else
    {
        echo "<script>alert('Error. Please Retry'); document.location.href = 'hospitalregistration.php';</script>";
    }
	
}


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Cancer Care Portal</title>

<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />

<script type="text/javascript">

	function doClear() {
	    document.getElementById('tun').value = "";
	    document.getElementById('tpw').value = "";
	    document.getElementById('tcp').value = "";
	    document.getElementById('tem').value = "";
	    document.getElementById('tmb').value = "";
	    document.getElementById('tnm').value = "";
	    document.getElementById('tpl').value = "";
	    document.getElementById('tad').value = "";
	    document.getElementById('tct').value = "";
	    document.getElementById('tws').value = "";
	}

	var emailreg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
  
	function doSubmit() {
	    if (document.getElementById('tun').value == "") {
	        alert("Please Enter User Name");
	    }
	    else if (document.getElementById('tpw').value == "") {
	        alert("Please Enter Password");
	    }
		else if (document.getElementById('tpw').value != document.getElementById('tcp').value) {
	        alert("Passwords should Match");
	    }
		else if (document.getElementById('tem').value == "") {
	        alert("Please Enter Email ID");
	    }
		else if ( emailreg.test(document.getElementById('tem').value) == false)
		{
	        alert("Invalid Email ID");
	    }
		else if (document.getElementById('tmb').value == "") {
	        alert("Please Enter Mobile");
	    }
		else if (isNaN(document.getElementById('tmb').value)) {
	        alert("Invalid Mobile Number");
	    }
		else if (document.getElementById('tmb').value.length != 10) {
	        alert("Invalid Mobile");
	    }
		else if (document.getElementById('tnm').value == "") {
	        alert("Please Enter Hospital Name");
	    }
		else if (document.getElementById('tpl').value == "") {
	        alert("Please Enter Place");
	    }
		else if (document.getElementById('tad').value == "") {
	        alert("Please Enter Address");
	    }
		else if (document.getElementById('tct').value == "") {
	        alert("Please Enter Contact Person");
	    }
		else if (document.getElementById('tws').value == "") {
	        alert("Please Enter Web Site");
	    }
	    else {
			document.getElementById('h').value == "1";
			document.getElementById('form1').action = 'hospitalregistration.php';
			document.getElementById('form1').submit();
	    }
	}
</script>

</head>
<body  class style="background-color:rgb(21,127,218);">
<form method='post' id='form1' name='form1' >
<input type='hidden' id='h' name='h' value='0' />
<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1><a href="#">Cancer Care Portal</a></h1>
		</div>

	</div>
	<div id="splash"><img src="images/img01.jpg" alt="" title="" style="width:980px; height:340px;" /></div>
	<!-- end #header -->
	<div id="page">
		<div id="page-bgtop">
			<div id="page-bgbtm">
				<div id="content">
					<div class="post">
						<h2 class="title"><a href="#"class style="color: rgb(21,127,218);"> Hospital Registration
                        
                        </a></h2>
						<div class="entry" style="line-height:25px;">


                            <label>User Name</label><br />
		                    <input type='text' id='tun' name='tun' class='txt' maxlength='14' style="width:400px;" /> <br />
		                   
							<label>Password</label><br />
		                    <input type='password' id='tpw' name='tpw'  class='txt'  maxlength='14'  style="width:400px;" /> <br />
							
							<label> Confirm Password</label><br />
		                    <input type='password' id='tcp' name='tcp'  class='txt'  maxlength='14'  style="width:400px;" /> <br />
							
							<label>Email Id</label><br />
		                    <input type='text' id='tem' name='tem' class='txt' maxlength='100' style="width:400px;" /> <br />
							
							<label>Mobile</label><br />
		                    <input type='text' id='tmb' name='tmb' class='txt' maxlength='14' style="width:400px;" /> <br />
							
							<label>Hospital Name</label><br />
		                    <input type='text' id='tnm' name='tnm' class='txt' maxlength='100' style="width:400px;" /> <br />
							
							<label>Place</label><br />
		                    <input type='text' id='tpl' name='tpl' class='txt' maxlength='50' style="width:400px;" /> <br />

							<label>Address</label><br />
		                    <input type='text' id='tad' name='tad' class='txt' maxlength='250' style="width:400px;" /> <br />

							<label>Contact Person</label><br />
		                    <input type='text' id='tct' name='tct' class='txt' maxlength='50' style="width:400px;" /> <br />

							<label>Website</label><br />
		                    <input type='text' id='tws' name='tws' class='txt' maxlength='100' style="width:400px;" /> <br />
							
							
		                    <div style="padding-top:15px;">
		                    <input type="button" value='Submit' class='btn' onclick='doSubmit();'  style="width:200px;"  />
		                    <input type="button" value='Clear' class='btn' onclick='doClear();'  style="width:200px;"  />
		                    </div>
		                
                            
                            <br /> <br />

 

						</div>

					</div>

					<div style="clear: both;">&nbsp;</div>
				</div>
				<!-- end #content -->
				<div id="sidebar">
					<ul>
						<li>
							<h2 style="color: rgb(21,127,218);"> Welcome</h2>
		                <div >
		                </div>
		                <br />
						</li>
						<li>
							<ul>
                                <li><a href="index.html">Home Page</a></li>
								<li><a href="login.php">Login Page</a></li>
								<li><a href="hospitalregistration.php"  style="text-decoration:none;">Hospital Registration</a></li>
                                <li><a href="patientregistration.php"  style="text-decoration:none;">Patient Registration</a></li>
								 <li><a href="activistregistration.php"  style="text-decoration:none;">Activist Registration</a></li>
                                <li><a href="forgotpassword.php">Forgot Password</a></li>
							</ul>
						</li>
					</ul>
				</div>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
		</div>
	</div>
	<!-- end #page -->
</div>

<div id="footer">

	<p>  Developed by Shad,Mruthul,Rivin and Sachin  </p>

</div>
</form>
</body>
</html>