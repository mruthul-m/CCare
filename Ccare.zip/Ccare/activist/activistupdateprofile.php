﻿<?php

session_start();

if( ! (isset($_SESSION['userid']) && isset($_SESSION['usertype']) && $_SESSION['usertype'] == 'activist')   )
header("location: ../login.php");

require_once "../include/database.inc";

$con = mysqli_connect($servername, $username, $password);
mysqli_select_db($con , $database);

$query = "select name,location,address,mobile,emailid from users join activistdetails on 
users.userid = activistdetails.activistid where userid='$_SESSION[userid]' and status = 1";

$result = mysqli_query($con, $query);
$row = mysqli_fetch_array($result);


if(isset($_POST['tnm']) && $_POST['tnm'] != "") 
{

	require_once("../include/database.inc");

    $con = mysqli_connect($servername, $username, $password);
	mysqli_select_db($con , $database);

    $query ="update users set mobile = '$_POST[tmb]', emailid = '$_POST[tem]'  where userid = '$_SESSION[userid]' ;";
	mysqli_query($con, $query);
		
    $rows = 0;
    $rows += mysqli_affected_rows($con);

	 $query ="update activistdetails set name = '$_POST[tnm]', location ='$_POST[tlo]',address = '$_POST[tad]'  where activistid = '$_SESSION[userid]' ;";
	mysqli_query($con, $query);
	//echo $query;
    if($rows >= 0)
    {
        echo "<script>alert('Activist Profile Updated'); document.location.href='activisthome.php';</script>";
    }
    else
    {
        echo "<script>alert('Error. Please Retry'); document.location.href = 'activisthome.php';</script>";
    }
	
}


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Cancer Care Portal</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
 <link rel="stylesheet" href="css/custom.css">
  <link rel="stylesheet" href="css/colors.css">


<link href="../css/style.css" rel="stylesheet" type="text/css" media="screen" />

<script type="text/javascript">

	function doClear() {
	   document.getElementById('tnm').value = "";
	    document.getElementById('tlo').value = "";
	    document.getElementById('tad').value = "";
		document.getElementById('tmb').value = "";
	    document.getElementById('tem').value = "";
	}

	

	function doChange() {
	    if (document.getElementById('tnm').value == "") {
	        alert("Please Enter Name");
	    }
	    else if (document.getElementById('tlo').value == "") {
	        alert("Please Enter location");
	    }
		else if (document.getElementById('tad').value == "") {
	        alert("Please Enter Address");
	    }
		else if (document.getElementById('tmb').value == "") {
	        alert("Please Enter Mobile");
	    }
		else if (document.getElementById('tem').value == "") {
	        alert("Please Enter Email ID");
	    }
	    else
		{
			document.getElementById('form1').action = 'activistupdateprofile.php';
			document.getElementById('form1').submit();
	    }
	}

</script>

</head>

<body class style="background-color:rgb(21,127,218);">
<form method="post" id="form1" action="" name="form1">

<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1><a href="#">Cancer Care Portal</a></h1>
		</div>

	</div>
	<div id="splash"><img src="../images/img01.jpg" alt="" title="" style="width:980px; height:340px;" /></div>
	<!-- end #header -->
	<div id="page">
		<div id="page-bgtop">
			<div id="page-bgbtm">
				<div id="content">
					<div class="post">
						<h2 class="title"><a href="#"class style="color: rgb(21,127,218);"> Update Activist Profile
                        
                        </a></h2>
						<div class="entry" style="line-height:25px;">
						
						<table style='line-height:30px;'>

						<tr>
							<td width='150'>Name</td>
							<td><input type='text' id='tnm' name='tnm' class='txt' maxlength='14' style="width:370px;"
							value = '<?php  if(isset($row)) echo $row[0]; else echo "";  ?>' 
							 /></td>
						</tr>

						<tr>
							<td width='125'>Location</td>
							<td><input type='text' id='tlo' name='tlo'  class='txt'  maxlength='50'  style="width:370px;"
							value = '<?php  if(isset($row)) echo $row[1]; else echo "";  ?>'
							 /> </td>
						</tr>

						<tr>
							<td width='125'>Address</td>
							<td><input type='text' id='tad' name='tad'  class='txt'  maxlength='250'  style="width:370px;"
							value = '<?php  if(isset($row)) echo $row[2]; else echo "";  ?>'
							 /> </td>
						</tr>
						 <tr>
							<td width='125'>Mobile</td>
							<td><input type='text' id='tmb' name='tmb'  class='txt'  maxlength='100'  style="width:370px;"
							value = '<?php  if(isset($row)) echo $row[3]; else echo "";  ?>'
							 /> </td>
						</tr>

						<tr>
							<td width='125'>Email ID</td>
							<td><input type='text' id='tem' name='tem'  class='txt'  maxlength='100'  style="width:370px;"
							value = '<?php  if(isset($row)) echo $row[4]; else echo "";  ?>'
							 /> </td>
						</tr>

						

						

						<tr>
							<td width='125'>&nbsp;</td>
							<td>
							<input type="button" value='Change' class='button' onclick='doChange();'  style="width:180px;"  />
							<input type="button" value='Clear' class='button' onclick='doClear();'  style="width:180px;"  />
							
							</td>
						</tr>

						</table>
 

						</div>

					</div>

					<div style="clear: both;">&nbsp;</div>
				</div>
				<!-- end #content -->
				<div id="sidebar">
					<ul>
						<li>
							<h2  style="color: rgb(21,127,218);"> Activist Home</h2>
		                <div >
		                </div>
		                <br />
						</li>
						<li>
							<ul>
                                 <li><a href="activisthome.php">Home</a></li>
								<li><a href="activistupdateprofile.php">Update Profile </a></li>
								<li><a href="managerequeststatus.php">Manage Service Request</a></li>
								<li><a href="managebloodrequest.php">Manage Blood Request</a></li>
								<li><a href="activistchangepassword.php"  style="text-decoration:none;">Change Password</a></li>
                               
                                <li><a href="../logout.php">Logout</a></li>
							</ul>
						</li>
					</ul>
				</div>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
		</div>
	</div>
	<!-- end #page -->
</div>

<div id="footer">

	<p> Developed by Shad,Mruthul,Rivin and Sachin</p>

</div>
</form>
</body>
</html>