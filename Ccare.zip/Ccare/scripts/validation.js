﻿
function checkAlphaNumSpace(alpha) {

    result = false;

    if (alpha.length >= 1) {
        i = 0;
        for (; i < alpha.length; i++) {
            if (!((username.charAt(i) >= "A" && username.charAt(i) <= "Z") ||
                        (username.charAt(i) >= "a" && username.charAt(i) <= "z") ||
                        (username.charAt(i) >= "0" && username.charAt(i) <= "9") ||
                        (username.charAt(i) == " "))
                ) break;
        }

        if (i == alpha.length) result = true;
    }

    return result;
}


