﻿
Partial Class scripts_validation
    Inherits System.Web.UI.Page

End Class
