﻿<?php

session_start();

if(isset($_POST['h']) && $_POST['h'] == '1')
{
	require_once "include/database.inc";

	$con = mysqli_connect($servername, $username, $password);
	mysqli_select_db($con , $database);

	$query = "select userid, usertype from users where username='$_POST[tun]' and password='$_POST[tpw]' and status = 1";

	$result = mysqli_query($con, $query);

	$row = mysqli_fetch_array($result);

	if(isset($row))
	{
		$_SESSION['userid'] = $row[0];
		$_SESSION['usertype'] = $row[1];

		if($_SESSION['usertype'] == 'admin')
		{
			echo "<script>document.location.href='admin/adminhome.php';</script>";
		}		
		else if($_SESSION['usertype'] == "hospital")
		{
			echo "<script>document.location.href='hospital/hospitalhome.php';</script>";
		}
		else if($_SESSION['usertype'] == "activist")
		{
			echo "<script>document.location.href='activist/activisthome.php';</script>";
		}
		else if($_SESSION['usertype'] == "patient")
		{
			echo "<script>document.location.href='patient/patienthome.php';</script>";
		}
		else
		{
			echo "<script>alert('Invalid Credentials. Please Retry'); document.location.href='login.php';</script>";
		}
	}
	else
	{
		echo "<script>alert('Invalid Credentials. Please Retry'); document.location.href='login.php';</script>";
	}

}

?>


<html>
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Cancer Care Portal</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
 <link rel="stylesheet" href="css/custom.css">
  <link rel="stylesheet" href="css/colors.css">





<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />

<script type="text/javascript">

	function doClear() {
	    document.getElementById('tun').value = "";
	    document.getElementById('tpw').value = "";
	}

	function doLogin() {
	    if (document.getElementById('tun').value == "") {
	        alert("Please Enter User Name");
	    }
	    else if (document.getElementById('tpw').value == "") {
	        alert("Please Enter Password");
	    }
	    else {
			document.getElementById('h').value = '1';
	        document.getElementById('form1').action = 'login.php';
	        document.getElementById('form1').submit();
	    }
	}

</script>

</head>
<body class style="background-color:rgb(21,127,218);">

               
                        
<form method='post' id="form1" action="" name="form1">

<input type='hidden' name='h' id='h' value='0' />

<div id="wrapper">
	<div id="header">
		<div id="logo">
			<h1><a href="#">Cancer Care Portal</a></h1>
		</div>

	</div>
	<div id="splash"><div id="img1">
	<img src="images/1.jpg" alt="" title="" style="width:980px; height:340px;" /></div></div>
	<!-- end #header -->
	<div id="page">
		<div id="page-bgtop">
			<div id="page-bgbtm">
				<div id="content">
					<div class="post">
						<h2 class="title"><a href="#"class style="color: rgb(21,127,218);"> Please Login
                 
                        
                        </a></h2>
						<div class="entry" style="line-height:25px;">


                            <label>User Name</label><br />
		                    <input type='text'autocomplete='off' id='tun' name='tun' class='txt' maxlength='14' style="width:400px;";/> <br />
		                    <label>Password</label> <br />
		                    <input type='password' id='tpw' name='tpw'  class='txt'  maxlength='14'  style="width:400px;"auto-complete="off"; /> <br />
		                    <div style="padding-top:15px;">
							
                                    <div class="form-group">
                                      
                                     <div class="left"><button type="submit" onclick='doLogin();'>submit</button>&nbsp;&nbsp;&nbsp;
                                    
                        <button type="clear" onclick='doClear();'>Clear</button></div>
		                    
		                    
		                    </div></div>
		                
                            
                            <br /> <br />

 

						</div>

					</div>

					<div style="clear: both;">&nbsp;</div>
				</div>
				<!-- end #content -->
				<div id="sidebar">
					<ul>
						<li>
							<h2  style="color: rgb(21,127,218);"> Welcome</h2>
		                <div >
		                </div>
		                <br />
						</li>
						<li>
							<ul>
                                <li><a href="index.html">Home Page</a></li>
								<li><a href="login.php">Login Page</a></li>
								<li><a href="hospitalregistration.php" >Hospital Registration</a></li>
                                <li><a href="patientregistration.php"  >Patient Registration</a></li>
								 <li><a href="activistregistration.php">Activist Registration</a></li>
                                <li><a href="forgotpassword.php">Forgot Password</a></li>
							</ul>
						</li>
					</ul>
				</div>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
		</div>
	</div>
	<!-- end #page -->
</div>

<div id="footer">

	<p>  Developed by Shad,Mruthul,Rivin and Sachin</p>

</div>
</form>
</body>
</html>